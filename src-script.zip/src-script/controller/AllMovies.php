<?php
$get  = $output[2];
$page = $output[1];
$atoz = false;
$pagelimit = FILES_PER_PAGE;
$db->pageLimit = FILES_PER_PAGE;
$db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
if ($get == "latest-movies") {
    $db->orderBy('f.id');
    $name = "Latest";
    $title = "Latest Movies - " . APP_NAME;
    $pageLink = APP_URL . '/movies/{{PAGE}}/latest-movies' . $endRoute;
} elseif ($get == "most-viewed") {
    $db->orderBy('f.view')->orderBy('f.id');
    $name = "Most Viewed Movies";
    $title = "Most Viewed Movies - " . APP_NAME;
    $pageLink = APP_URL . '/movies/{{PAGE}}/most-viewed' . $endRoute;
} elseif ($get == "trending") {
    $db->where('f.trend', 1)->orderBy('f.id');
    $name = "Trending";
    $title = "Trending Movies - " . APP_NAME;
    $pageLink = APP_URL . '/movies/{{PAGE}}/trending' . $endRoute;
} else if (strlen($get) == 1 || $get == 'a-to-z') {
    $atoz = true;
    if ($get == 'a-to-z') {
        $db->orderBy('release_date');
        $name = 'A to Z';
        $title = 'A to Z All Movies Download - ' . APP_NAME;
        $pageLink = APP_URL . '/movies/{{PAGE}}/a-to-z' . $endRoute;
        $Alpaupper = '';
    } else {
        $Alpalower = strtolower($get);
        $Alpaupper = strtoupper($Alpalower);
        $db->where('f.name', $Alpaupper . '%', 'LIKE')->orderBy('release_date');
        $name = $Alpaupper;
        $title = $Alpaupper . ' - Starting All Movies - ' . APP_NAME;
        $pageLink = APP_URL . '/movies/{{PAGE}}/' . $Alpalower . $endRoute;
    }
} else {
    if (ERROR_PAGE == true) {
        require __DIR__ . '/ErrorPage.php';
    } else {
        Redirect($AppProtocol . $request_path);
    }
    exit;
}
$files = $db->where('f.status', 1)->paginate(TABLE_FILES . ' f', $page, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');
$totalPage = $db->totalPages;
$YouMayMovies = $db
    ->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER")
    ->orderBy('RAND()')
    ->where('f.trend', 1)->orWhere('f.newtag', 1)->where('f.status', 1)->get(TABLE_FILES . ' f', 5, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 2,
    "item" => [
        "@id" => $AppProtocol.$request_uri,
        "name" => $name
    ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' . $AppProtocol.$request_uri . '">' . $name . '</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb
];
require_once $Template . '/header.php';
require_once $Template . '/AllMovies.php';
require_once $Template . '/footer.php';

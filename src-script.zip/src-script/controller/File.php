<?php
$id = $output[1];
unset($output, $output2);
if ($data = $db->where('old_slug', $id)->getOne(TABLE_FILES, 'slug')) {
  Redirect(APP_URL . '/' . $data['slug']);
  exit;
}
$db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
$db->where('f.slug', $id);
$db->where('f.status', 1);
$selectData = 'f.*,c.name as category_name,c.folder,c.thumb as category_thumb,c.slug as category_slug,c.parentid as c_parentid';
$file = $db->getOne(TABLE_FILES . ' f', $selectData);
if (!$file) {
  if (ERROR_PAGE == true) {
    require __DIR__ . '/ErrorPage.php';
  } else {
    Redirect(APP_URL);
  }
  exit;
}

$db->where('id', $file['id'])->update(TABLE_FILES, ['view_today' => $db->inc(1), 'view' => $db->inc(1)]);
$releasedate = date('Y', strtotime($file['release_date']));
$parentids = array_filter(explode('/', $file['folder']));
array_shift($parentids);
array_pop($parentids);
$bpos = 1;
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
if ($parentids) {
  $breadcrumbs = $db->where('id', $parentids, 'IN')->orderBy('id', 'ASC', $parentids)->get(TABLE_CAT);
  foreach ($breadcrumbs as $bread) {
    $bpos++;
    $breadcrumb[] =  [
      "@type" => "ListItem",
      "position" => $bpos,
      "item" => [
        "@id" => APP_URL . '/category/' . $bread['slug'] . $endRoute,
        "name" => $bread['name']
      ]
    ];
    $breadhtml .= '<li class="breadcrumb-item"><a href="' . APP_URL . '/category/' . $bread['slug'] . $endRoute . '">' . $bread['name'] . '</a></li>';
  }
}
$bpos++;
$breadcrumb[] =  [
  "@type" => "ListItem",
  "position" => $bpos,
  "item" => [
    "@id" =>  APP_URL . '/category/' . $file['category_slug'] . $endRoute,
    "name" =>  $file['category_name']
  ]
];
$bpos++;
$breadcrumb[] =  [
  "@type" => "ListItem",
  "position" => $bpos,
  "item" => [
    "@id" =>  APP_URL . '/' . $file['slug'] . $endRoute,
    "name" =>  $file['name'] . ' (' . $releasedate . ')'
  ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' . APP_URL . '/category/' . $file['category_slug'] . $endRoute  . '">' . $file['category_name'] . '</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
  "@context" => "https://schema.org",
  "@type" => "BreadcrumbList",
  "itemListElement" => $breadcrumb
];
$genres = '';
if ($file['genre']) {
  $genress = explode(',', $file['genre']);
  array_filter($genress);
  foreach ($genress as $gr)
    $genres .= '<a href="' . APP_URL . '/genre/' . slug($gr) . $endRoute . '">' . $gr . '</a> ,';
}
$stars = '';
if ($file['star']) {
  $starss = explode(',', $file['star']);
  array_filter($starss);
  foreach ($starss as $gr)
    $stars .= '<a href="' . APP_URL . '/star/' . slug($gr) . $endRoute . '">' . $gr . '</a> ,';
}
$directors = '';
if ($file['director']) {
  $directorss = explode(',', $file['director']);
  array_filter($directorss);
  foreach ($directorss as $gr)
    $directors .= '<a href="' . APP_URL . '/director/' . slug($gr) . $endRoute . '">' . $gr . '</a> ,';
}
$PlayLinks = array();
$DownLinks = array();
$MLinks = getLinks($file['id']);
if ($MLinks) {
  foreach ($MLinks as $l) {
    if ($l['is_link'] == 1) {
      array_push($DownLinks, $l);
    } else {
      array_push($PlayLinks, $l);
    }
  }
}

$db->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER");
$db->orderBy('RAND()');
$db->where('f.cid', $file['cid']);
$db->where('f.id', $file['id'], '!=');
$ReletedFiles = $db->get(TABLE_FILES . ' f', RELETED_FILES_LIMIT, 'f.id,f.name,f.slug,f.release_date');

$relids = array($file['id']);
if ($ReletedFiles) {
  $relids = array_merge($relids, array_column($ReletedFiles, 'id'));
}
$sq = $db->subQuery();
$sq->where('parentid', $file['c_parentid']);
$sqIds =  $sq->get(TABLE_CAT, null, 'id');
$YouMayMovies = $db
  ->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER")
  ->orderBy('RAND()')
  // ->where('f.release_date',$releasedate.'%','LIKE')
  ->where('f.id', $relids, 'NOT IN')
  ->where('f.status', 1)->where('f.cid', $sqIds, 'IN')->get(TABLE_FILES . ' f', 6, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');
unset($relids);

$reletedstars = $db->where('status', 1)->orderBy('RAND()')->get(TABLE_STAR, RELETED_FILES_LIMIT, 'name,slug');
$releteddirector = $db->where('status', 1)->orderBy('RAND()')->get(TABLE_DIRECTOR, RELETED_FILES_LIMIT, 'name,slug');
$thumbWH = explode('x', PREVIEW_THUMB);
if ($file['thumb']) {
  $thumb = APP_URL . '/' . $file['folder'] . PREVIEW_THUMB . '/' . $file['thumb'];
  if (THUMB_OGIMAGE == 1)
    $metaogimage = APP_URL . '/' . $file['folder'] . META_OG_THUMB . '/' . $file['thumb'];
} else {
  $thumb = APP_URL . '/assets/images/movie.svg';
}
$title = $file['meta_title'] ? $file['meta_title']  . ' - ' . APP_NAME : str_replace(array('{{FILENAME}}', '{{CATEGORY_NAME}}', '{{RELEASE_DATE}}'), array(title($file['name']), title($file['category_name']), $releasedate), $lang['FILE_TITLE']) . ' - ' . APP_NAME;
$metadescription = $file['meta_des'] ? $file['meta_des'] : str_replace(array('{{FILENAME}}', '{{CATEGORY_NAME}}', '{{RELEASE_DATE}}'), array(title($file['name']), title($file['category_name']), $releasedate), $lang['FILE_META_DESCRIPTION']);
$metakeywords = $file['meta_keyw'] ? $file['meta_keyw'] : str_replace(array('{{FILENAME}}', '{{CATEGORY_NAME}}', '{{RELEASE_DATE}}'), array(title($file['name']), title($file['category_name']), $releasedate), $lang['FILE_META_KEYWORDS']);
$autotags = str_replace(array('{{FILENAME}}', '{{CATEGORY_NAME}}', '{{RELEASE_DATE}}'), array($file['name'], $file['category_name'], $releasedate), $lang['FILE_AUTO_TAG']);
require_once $Template . '/header.php';
require_once $Template . '/File.php';
require_once $Template . '/footer.php';

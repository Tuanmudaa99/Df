<?php
$sort = $output[3];
$page = $output[2];

if ($output[1] == "genres") {
    $name = 'Genres';
    $dbtable = 'genres';
    $curroute = 'genres';
    $goroute = 'genre';
}
if ($output[1] == "directors") {
    $name = 'Directors';
    $dbtable = 'directors';
    $curroute = 'directors';
    $goroute = 'director';
}
if ($output[1] == "stars") {
    $name = 'Stars';
    $dbtable = 'stars';
    $curroute = 'stars';
    $goroute = 'star';
}
if ($sort != 'a-to-z') {
    $title = strtoupper($sort) . ' Starting All '.$name.' List -' . APP_NAME;
    $heading = ucwords($sort) . ' - Starting All '.$name.' List';
} else {
    $title =  $name.' List - ' . APP_NAME;
    $heading = $name.' List';
}
$breadhtml = '<nav aria-label="breadcrumb"><ol class="breadcrumb mt-2"><li class="breadcrumb-item"><a href="' . APP_URL . '">Home</a></li>';
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 2,
    "item" => [
        "@id" => $AppProtocol.$request_uri,
        "name" => $name
    ]
];
$breadhtml .= '<li class="breadcrumb-item"><a href="' . $AppProtocol.$request_uri . '">' . $name . '</a></li>';
$breadhtml .= '</ol></nav>';
$schema = [
    "@context" => "https://schema.org",
    "@type" => "BreadcrumbList",
    "itemListElement" => $breadcrumb
];
$metakeywords = '';
$pageLink = APP_URL . '/'.$curroute.'/{{PAGE}}/' . $sort . $endRoute;

$pagelimit = FILES_PER_PAGE;
$db->pageLimit = $pagelimit;
if ($sort != 'a-to-z') {
    $db->where('name', $sort . '%', 'LIKE');
    $db->orderBy('name', 'ASC')->orderBy('id');
} else {
    $db->orderBy('pos', 'ASC')->orderBy('id');
}
$db->where('status', 1);
$collection = $db->paginate($dbtable, $page,'name,thumb,slug');
$totalPage = $db->totalPages;
$YouMayMovies = $db
    ->join(TABLE_CAT . ' c', 'f.cid=c.id', "INNER")
    ->orderBy('RAND()')
    ->where('f.trend', 1)->orWhere('f.newtag', 1)->where('f.status', 1)->get(TABLE_FILES . ' f', 5, 'f.name,f.slug,f.thumb,f.duration,f.view,f.release_date,c.folder');

require_once $Template . '/header.php';
require_once $Template . '/AllCollection.php';
require_once $Template . '/footer.php';

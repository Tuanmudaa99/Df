<?php
define('BASE_URL','movie.code');
define('APP_URL', 'http://movie.code');
define('APP_HTTPS','false');
define('APP_NAME', 'Movie Scripts');
define('TEMPLATE', 'classic');
define('ERROR_PAGE',false);
define('HOME_UPDATES_TYPE',1);
define('HOME_UPDATES_LIMIT', '25');
define('FILES_PER_PAGE', 12);
define('CATEGORY_PER_PAGE', 12);
define('RELETED_FILES_LIMIT', 5);
define('ADMIN_DIR', 'Admin');
define('CATICON_SIZES', '54x80,117x172,182x268');
define('FILE_THUMB_SIZES','54x80,117x172,182x268');
define('MP3TAG_COVER','182x268');
define('LIST_THUMB', '54x80');
define('CARD_THUMB', '117x172');
define('PREVIEW_THUMB', '182x268');
define('META_OG_THUMB', '182x268');
define('THUMB_OGIMAGE',1);
define('ADS_NETWORK', 'ADSENSE,TABOOLA,OWNADS'); //ADS NETWORK
define('DEFAULT_ADS', 'ADSENSE');
define('ADVT_EACH',6);
define('THUMB_FORMAT', 'jpg');
define('THUMB_QUALITY', '100');
define('WEBPUSH', '0');
define('WEBPUSH_SENDER_ID','');
define('WEBPUSH_REST_KEY','');
//DATABASE TABLE 
define('TABLE_CAT', 'category');
define('TABLE_FILES', 'file');
define('TABLE_ADMIN', 'admin');
define('TABLE_DIRECTOR','directors');
define('TABLE_GENRE', 'genres');
define('TABLE_STAR','stars');
define('TABLE_LINKS','downlinks');
//HOME PAGE TITLE
$title = 'Latest Hindi Bollywood Movie Watch Online and Download Free';
$metadescription = 'Watch free and download hindi bollywood movie hindi, Hollywood Movie Hindi Dubbed and South Indian Movie and many more';
$metakeywords = 'hindi bollywood movie, hollywood movie, south indian latest movie, hindi dubbed movie download';
$metaogsitename = APP_NAME;
$metatwsite = APP_NAME;
$metaogimage = APP_URL.'/assets/images/og.jpg';
$metarobots = 'index,follow';
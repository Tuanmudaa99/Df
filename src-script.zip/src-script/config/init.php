<?php
error_reporting(0);
$RootPath = realpath(__DIR__ . '/../');
require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/language.php';
require_once __DIR__ . '/function.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
if (!file_exists($RootPath . '/lock.txt')) {
    Redirect('../install');
}
$db = new MysqliDb(array(
    'host' => $dbhost,
    'username' => $dbuser,
    'password' => $dbpass,
    'db' => $dbname,
    'port' => $dbport,
    'prefix' => $dbprefix,
    'charset' => $dbcharset
));
if (APP_HTTPS == 1) {
    $wwwurl = 'www.' . BASE_URL;
    $httpsurl = 'https://' . BASE_URL;
    if ($_SERVER['HTTP_HOST'] == $wwwurl || empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] == "off") {
        header('Location: ' . $httpsurl . $_SERVER['REQUEST_URI'], TRUE, 301);
        exit;
    }
}
$Route = '';
$AmpURL = '';
$schema = array();
$allowExt = array('jpg', 'png', 'gif', 'jpeg', 'webp', 'mp4', 'mkv', 'wmv', 'mov');
$breadcrumb[] =  [
    "@type" => "ListItem",
    "position" => 1,
    "item" => [
        "@id" => "" . APP_URL . "",
        "name" => "Home"
    ]
];
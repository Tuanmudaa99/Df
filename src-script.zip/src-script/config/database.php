<?php
$dbhost = "localhost"; //DATABASE HOST
$dbport = "3306"; //DATABASE PORT
$dbuser = "root"; //DATABASE USERNAME
$dbpass = ""; //DATABASE USER PASSWORD
$dbname = "movie"; //DATABASE NAME
$dbprefix = ""; // DATATBASE PREFIX
$dbcharset = "utf8"; //DATABASE CHARTSET
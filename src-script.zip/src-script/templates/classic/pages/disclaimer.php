<main class="container bg-light shadow-sm rounded-bottom border-top">
    <h1 class="p-2 m-2 border-bottom fs-4">Disclaimer (DMCA)</h1>
    <p>

        &raquo; 1.Please Read The Disclaimer Of (<?php echo APP_NAME; ?>) Before Download Anything From <?php echo APP_URL; ?><strong>
            <span class="text-danger"><?php echo APP_URL; ?></span>
        </strong></a></p>

    <p>
        &raquo; 2.This is a promotional website only, All the downloadable content provided on this site (All materials) is for testing/promotion purposes only.All files placed here are for introducing purpose.</p>
    <p>
        &raquo; 3.We highly ENCOURAGE users to BUY the CDs or DVDs of the movie or the music they like. Please, buy original Songs/contents from author or developer site!</p>
    <p>

        &raquo; 4.If you Do not agree to all the terms, please disconnect from this site now itself.</p>

    <p>

        &raquo; 5.By remaining at this site, you affirm your understanding and compliance of the above disclaimer and absolve this site of any responsibility henceforth</p>

    <p>

        &raquo; 6.All files found on this site have been collected from various sources across the web and are believed to be in the "public domain".</p>

    <p>

        &raquo; 7.All the logos and stuff are the property of their respective owners.</p>

    <p>

        &raquo; 8.You should DELETE IT(data) within 24 hours and make a point to buy the original CD or DVD from a local or online store. </p>

    <p>

        &raquo; 9. If you are the rightful owner of any contents posted here, and object to them being displayed or If you are one of representativities of copy rights department and you dont like our conditions of store, Please Contact Us We will remove it in 24 hour!</p>

    <p>

        &raquo; 10. Downloading at your own risk!!!</p>
    <h4>Contact Us: <strong>contact@<?php echo BASE_URL; ?></strong></h4>
    <hr>
</main>
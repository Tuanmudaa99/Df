<?php
if ($listitems) {
    $cnt = 0;
    if ($list_href == 'star')
        $thumbdir = 'starthumb';
    elseif ($list_href == 'director') {
        $thumbdir = 'directorthumb';
    } else {
        $thumbdir = 'genrethumb';
    }
    $thumbsize = explode('x', LIST_THUMB);
    foreach ($listitems as $item) {
        $cnt++;
        if ($item['thumb']) {
            $thumb = APP_URL . '/upload_file/' .$thumbdir .'/'. LIST_THUMB . '/' . $item['thumb'];
        } else {
            $thumb = APP_URL . '/assets/images/thumbnail.svg';
        }
        echo '<li class="list-group-item">
    <a href="' . APP_URL . '/' . $list_href . '/' . $item['slug'] . $endRoute . '" class="d-flex list-m">
        <img src="' . APP_URL . '/assets/images/thumbnail.svg" data-src="' . $thumb . '" class="lazy float-start rounded" alt="' . $item['name'] . '" width="' . $thumbsize[0] . '" height="' . $thumbsize[1] . '">
        <div class="ms-2 text-truncate align-self-center w-100">
            <h4>' . $item['name'] . '</h4>
        </div>
    </a>
</li>';
        if ($cnt % ADVT_EACH == 0) {
            include(getAds($AdsPath . '/between_listitem'));
        }
    }
    unset($listitems);
    unset($thumbsize);
    unset($list_href);
}

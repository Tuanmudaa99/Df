<?php
if($categories){
$cnt = 0;
$thumbsize = explode('x',CARD_THUMB);
foreach($categories as $cat){
  $cnt++;
  if($cat['thumb']){
    $thumb = APP_URL.'/upload_file/folderthumb/'.CARD_THUMB.'/'.$cat['thumb'];
   } else{
     $thumb = APP_URL.'/assets/images/folder.svg';
   }
   echo '<div class="col">
   <a data-bs-toggle="tooltip" title="'.$cat['name'].'" href="'.APP_URL.'/category/'.$cat['slug'].$endRoute.'" class="card movie" width="'.$thumbsize[0].'" height="'.$thumbsize[1].'">
     <img src="'.APP_URL.'/assets/images/folder.svg" data-src="'.$thumb.'" class="lazy card-img-top" alt="'.$cat['name'].'">
     <div class="movie-body">
       <h4>'.$cat['name'].'</h4>
       <span>Total: '.$cat['totalitem'].'</span>
     </div>
   </a>
 </div>';
if($cnt % ADVT_EACH == 0){
include(getAds($AdsPath . '/between_catlist'));
}
}
unset($categories);
unset($thumbsize);
}

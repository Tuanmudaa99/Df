<main class="container bg-light shadow-sm rounded-bottom border-top pb-2">
   <div class="row">
      <div class="col-12 col-lg-8">
            <?php echo $breadhtml; ?>
         <h1 class="px-2 pt-2 mb-1 text-dark text-truncate fs-5 fw-normal text-uppercase"><?php echo $name; ?> All Movies</h1>
         <h2 class="pb-2 ps-2 mb-3 text-truncate fs-6 fw-normal border-bottom"><i class="fa fa-user" aria-hidden="true"></i> <?php echo $name; ?></h2>
         <div class="row row-cols-3 row-cols-sm-4 row-cols-md-6 bg-light g-1 g-sm-2 mb-3">
            <?php
            require_once __DIR__ . '/_files_list.php';
            ?>
         </div>
         <?php
         echo skyPageNavigate($totalPage, $page, $pagelimit, $pageLink);
         ?>

      </div>
      <div class="col-12 col-lg-4">
         <?php include(getAds($AdsPath . '/sidebar_before')); ?>
         <h3><i class="fa fa-random" aria-hidden="true"></i> You May Also Like</h3>
         <ul class="list-group sb-list">
            <?php
            $listitems = $ReletedAlso;
            $list_href = 'director';
            require_once __DIR__ . '/_list_itemExtra.php';
            unset($ReletedAlso); ?>
         </ul>
      </div>
   </div>
  <p class="card card-body p-2 my-2 fw-light"><?php echo $autotags;?></p>
</main>
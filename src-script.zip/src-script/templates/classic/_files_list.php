<?php 
if($files){
$cnt = 0;
$thumbsize = explode('x',CARD_THUMB);
foreach($files as $file){
  $cnt++;
  if($file['thumb']){
    $thumb = APP_URL.'/'.$file['folder'].CARD_THUMB.'/'.$file['thumb'];
   } else{
     $thumb = APP_URL.'/assets/images/movie.svg';
   }
   $ryear = date('Y',strtotime($file['release_date']));
   echo '<div class="col">
   <a data-bs-toggle="tooltip" title="'.$file['name'].' ('.$ryear.')" href="'.APP_URL.'/movie/'.$file['slug'].$endRoute.'" class="card movie">
     <img src="'.APP_URL.'/assets/images/movie.svg" data-src="'.$thumb.'" class="lazy card-img-top" alt="'.$file['name'].'">
     <div class="movie-body">
       <h4>'.$file['name'].' <span>('.$ryear.')</span></h4>
       <span><i class="fa fa-clock-o" aria-hidden="true"></i>
       '.$file['duration'].' Min</span>
     </div>
   </a>
 </div>';
if($cnt % ADVT_EACH == 0){
include(getAds($AdsPath . '/between_fileslist'));
}
}
unset($files);
unset($thumbsize);
}
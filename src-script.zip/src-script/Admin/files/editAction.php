<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
$id = Input('id');
$thumbname = '';
$thumbfrom = Input('thumbfrom');
$filename  = trim(Input('filename'));
if ($id != '') {
  $file = $db->where('id', $id)->getOne(TABLE_FILES);

  $cid = $file['cid'];
  $category = $db->where('id', $cid)->getOne(TABLE_CAT);
  if (!$category || !$file) {
    $response = ['status' => 2, 'message' => 'Category / File Does not find database'];
    echo json_encode($response);
    exit;
  }
} else {
  $response = ['status' => 2, 'message' => 'File Id Missing'];
  echo json_encode($response);
  exit;
}
$des = Input('description',true);
$des = str_replace(array('<p><br></p>','<p></p>'), '', $des);

$savePath = $RootPath . '/' . $category['folder'];
$mkdir = rtrim($savePath, '/');
if (!is_dir($mkdir)) {
  mkdir($mkdir, 0777, true);
}

$w_pos = Input('w_pos') ? Input('w_pos') : 'top-left';
$SaveThumbnail = $RootPath . '/' . $category['folder'];

if ($thumbfrom == 'EXTERNAL_LINK') {
  $thumbURL = trim(Input('thumb_url'));
  $thumb_ext = pathinfo($thumbURL, PATHINFO_EXTENSION);
  if ($thumbURL && $thumb_ext) {
    $tmp_thumbname = 'tmp_thumb.' . $thumb_ext;
    $saveThumb = $RootPath . '/' . $category['folder'] . $tmp_thumbname;
    if (urlCopy($thumbURL, $saveThumb)) {
      $thumbname = $file['thumb'] ? pathinfo($file['thumb'], PATHINFO_FILENAME) : uniqid('thumb_');
      genThumb($saveThumb, $SaveThumbnail, $thumbname, $w_pos, true);
      unlink($saveThumb);
    }
  }
} else {
  if ($_FILES['thumb']['name']) {
    $thumbname = $file['thumb'] ? pathinfo($file['thumb'], PATHINFO_FILENAME) : uniqid('thumb_');
    genThumb($_FILES['thumb']['tmp_name'], $SaveThumbnail, $thumbname, $w_pos, true);
  }
}

$file_name = pathinfo($filename, PATHINFO_FILENAME);

$release_date = Input('release_date');
$genre = InputArray('genre');

$genre = $genre?implode(',',$genre):'';


$director = Input('director');
$star = Input('star');

if ($release_date) {
  $release_date = date('Y-m-d', strtotime($release_date));
}

$duration = Input('duration');

$fileslug = Input('slug') ? Input('slug') : genSlug($file_name);
$oldslug = ($fileslug != $file['slug']) ? $file['slug'] : '';
$data = [
  'name' => $file_name,
  'cid' => $file['cid'],
  'old_slug' => $oldslug,
  'slug' => Input('slug') ? Input('slug') : genSlug($file_name),
  'thumb' => $thumbname ? $thumbname . '.' . THUMB_FORMAT : $file['thumb'],
  'director' => $director,
  'genre' => $genre,
  'star' => $star,
  'des' => $des,
  'duration' => $duration,
  'release_date' => $release_date ? $release_date : $file['release_date'],
  'pos' => Input('pos') ? Input('pos') : 0,
  'imdbid' => Input('imdbid')?Input('imdbid'):0,
  'rating' => Input('rating')?Input('rating'):0,
  'total_rate' => Input('total_rate')?Input('total_rate'):0,
  'meta_title' => Input('meta_title'),
  'meta_keyw' => Input('meta_keyw'),
  'meta_des' => Input('meta_des'),
  'newtag' => Input('new_tag') ? Input('new_tag') : 0,
  'trend' => Input('trend') ? Input('trend') : 0,
  'status' => Input('status') ? Input('status') : 0,
  'created_at' => $file['created_at'],
];

if ($db->where('id', $id)->update(TABLE_FILES, $data)) {
  addDownLinks($id);
  if ($file['director'] != $director) {
    genExtra($director, TABLE_DIRECTOR);
  }
  if ($file['star'] != $star) {
    genExtra($star, TABLE_STAR);
  }

  $response = ['status' => 1, 'message' => $file_name.' Movie Successfuly Uploaded'];
  echo json_encode($response);
  exit;
} else {
  $response = ['status' => 2, 'message' => $db->getLastError()];
  echo json_encode($response);
  exit;
}

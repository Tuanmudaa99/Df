<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
$thumbname = '';
$thumbfrom = Input('thumbfrom');
$cid = Input('cid');
$filename  = trim(Input('filename'));
if ($cid != "") {
  $category = $db->where('id', $cid)->getOne(TABLE_CAT);
  if (!$category) {
    $response = ['status' => 2, 'message' => 'Category / File Does not find database'];
    echo json_encode($response);
    exit;
  }
} else {
  $response = ['status' => 2, 'message' => 'Category ID Missing'];
  echo json_encode($response);
  exit;
}

$des = Input('description',true);
$des = str_replace(array('<p><br></p>','<p></p>'), '', $des);
$savePath = $RootPath . '/' . $category['folder'];
$mkdir = rtrim($savePath, '/');
if (!is_dir($mkdir)) {
  mkdir($mkdir, 0777, true);
}
  $w_pos = Input('w_pos') ? Input('w_pos') : 'top-left';
  $SaveThumbnail = $RootPath . '/' . $category['folder'];

  if ($thumbfrom == 'EXTERNAL_LINK') {
    $thumbURL = trim(Input('thumb_url'));
    $thumb_ext = pathinfo($thumbURL, PATHINFO_EXTENSION);
    if ($thumbURL && $thumb_ext) {
      $tmp_thumbname = 'tmp_thumb.' . $thumb_ext;
      $saveThumb = $RootPath . '/' . $category['folder'] . $tmp_thumbname;
      if (urlCopy($thumbURL, $saveThumb)) {
        $thumbname = uniqid('thumb_');
        genThumb($saveThumb, $SaveThumbnail, $thumbname, $w_pos);
        unlink($saveThumb);
      }
    }
  } else {
    if ($_FILES['thumb']['name']) {
      $thumbname = uniqid('thumb_');
      genThumb($_FILES['thumb']['tmp_name'], $SaveThumbnail, $thumbname, $w_pos);
    }
  }

  $release_date = Input('release_date');
  if ($release_date)
    $release_date = date('Y-m-d', strtotime($release_date));

  $genre = InputArray('genre');
  $genre = $genre?implode(',',$genre):'';

  $director = Input('director');
  $star = Input('star');


  $duration = Input('duration');
  $data = [
    'name' => $filename,
    'cid' => $cid,
    'slug' => Input('slug') ? Input('slug') : genSlug($filename),
    'thumb' => $thumbname ? $thumbname . '.' . THUMB_FORMAT : '',
    'director' => $director,
    'star' => $star,
    'genre' => $genre,
    'des' => $des,
    'duration' => $duration,
    'view_today' => 0,
    'view' => 0,
    'release_date' => $release_date ? $release_date : date('Y-m-d'),
    'pos' => Input('pos') ? Input('post') : 0,
    'newtag' => Input('new_tag') ? Input('new_tag') : 0,
    'trend' => Input('trend') ? Input('trend') : 0,
    'imdbid' => Input('imdbid') ? Input('imdbid') : 0,
    'rating' => Input('rating') ? Input('rating') : 0,
    'total_rate' => Input('total_rate') ? Input('total_rate') : 0,
    'meta_title' => Input('meta_title'),
    'meta_keyw' => Input('meta_keyw'),
    'meta_des' => Input('meta_des'),
    'status' => Input('status') ? Input('status') : 0,
    'created_at' => $db->now(),
  ];

  if ($id = $db->insert(TABLE_FILES, $data)) {

    addDownLinks($id);

    $parentids = array_filter(explode('/', $category['folder']));
    array_shift($parentids);
    if ($parentids) {
      $db->where('id', $parentids, 'IN')->update(TABLE_CAT, ['totalitem' => $db->inc(1)]);
    }

    if ($director) {
      genExtra($director, TABLE_DIRECTOR);
    }
    if ($star) {
      genExtra($star, TABLE_STAR);
    }

    $response = ['status' => 1, 'message' => $filename . ' Movie Successfuly Uploaded'];
    echo json_encode($response);
    exit;
  } else {
    if ($thumbname) {
      $appsizes = explode(',', FILE_THUMB_SIZES);
      foreach ($appsizes as $wh) {
        $Imgwh = explode('x', $wh);
        $ImgDir =  $RootPath . '/' . $category['folder'] . $wh . '/' . $thumbname;
        if (file_exists($ImgDir)) {
          unlink($ImgDir);
        }
      }
    }
    $response = ['status' => 2, 'message' => $db->getLastError()];
    echo json_encode($response);
    exit;
  }
<?php

/**
 * @author Pratik Dev <webmaster.pratik@gmail.com>
 */
require_once __DIR__ . '/../header.php';

$pathc = '';
if ($parentid = Input('cid')) {
    $pathc = '<li class="breadcrumb-item"><a href="../category/index.php">Home</a></li>';
    $db->where('id', $parentid);
    $category = $db->getOne(TABLE_CAT);
    $title = $category['name'];

    $parentids = array_filter(explode('/', $category['folder']));
    array_shift($parentids);

    if ($parentids) {
        $breadcrumbs = $db->where('id', $parentids, 'IN')->orderBy('id', 'ASC', $parentids)->get(TABLE_CAT);
        foreach ($breadcrumbs as $bread) {
            if ($bread['totalitem'] > 0 && $bread['subcate'] == 0)
                $pathc .= '<li class="breadcrumb-item"><a href="?cid=' . $bread['id'] . '">' . $bread['name'] . '</a></li>';
            else {
                $pathc .= '<li class="breadcrumb-item"><a href="../category/index.php?parentid=' . $bread['id'] . '">' . $bread['name'] . '</a></li>';
            }
        }
    }
} else {
    $pathc .= '<li class="breadcrumb-item"><a href="../index.php">Home</a></li>';
    $pathc .= '<li class="breadcrumb-item"><a href="index.php">Movies</a></li>';
    $parentid = "";
    $title = "Movies";
}
?>
<div class="container-fluid">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <?php echo $pathc; ?>
        </ol>
    </nav>
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary"><?php echo $title; ?></h6>
            </div>
        </div>
        <div class="card-body">
            <?php
            if ($parentid)
                if ($category['subcate'] == 0) : ?>
                <p><a href="../files/create.php?cid=<?php echo $parentid; ?>" class="btn btn-info">Add Movie</a></p>
            <?php endif; ?>
            <div class="table-responsive">
                <table id="datalist" name="files" class="table table-striped table-bordered files" width="100%" cellspacing="0">
                    <thead class="bg-info text-white">
                        <tr>
                            <th>Id</th>
                            <th>Thumb</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Duration</th>
                            <th>Director</th>
                            <th>Star</th>
                            <th>Genre</th>
                            <th>Release</th>
                            <th>Rating</th>
                            <th>Total Rate</th>
                            <th>View</th>
                            <th>Order</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/../footer.php';
?>
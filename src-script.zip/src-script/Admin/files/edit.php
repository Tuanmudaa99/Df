<?php

/**
 * @author Pratik Dev <webmaster.pratik@gmail.com>
 */
require_once __DIR__ . '/../header.php';
$file = $db->where('id', Input('id'))->getOne(TABLE_FILES);
$pathc = '';
if ($parentid = $file['cid']) {
    $pathc = '<li class="breadcrumb-item"><a href="../category/index.php">Home</a></li>';
    $db->where('id', $parentid);
    $category = $db->getOne(TABLE_CAT);
    $title = $category['name'];

    $parentids = array_filter(explode('/', $category['folder']));
    array_shift($parentids);

    if ($parentids) {
        $breadcrumbs = $db->where('id', $parentids, 'IN')->orderBy('id','ASC',$parentids)->get(TABLE_CAT);
        foreach ($breadcrumbs as $bread) {
            if ($bread['totalitem'] > 0 && $bread['subcate'] == 0)
            $pathc .= '<li class="breadcrumb-item"><a href="../files/index.php?cid=' . $bread['id'] . '">' . $bread['name'] . '</a></li>';
        else {
            $pathc .= '<li class="breadcrumb-item"><a href="../category/index.php?parentid=' . $bread['id'] . '">' . $bread['name'] . '</a></li>';
        }
        }
    }
    $filename = $file['name'];
?>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <?php echo $pathc; ?>
            </ol>
        </nav>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <div class="d-flex justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Edit Movie</h6>
                </div>
            </div>
            <div class="card-body">
                <div class="alert alert-success alertDialog" style="display: none;" role="alert">
                </div>
                <div id="progressbar" class="progress mb-2" style="height: 25px;display:none">
                    <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="100" style="width: 5%">5%</div>
                </div>
                <form id="uploadform" action="editAction.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="id" value="<?php echo $file['id']; ?>">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="File">Name:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" value="<?php echo $filename; ?>" name="filename" id="filename" placeholder="Title of Movie">
                                <div class="input-group-append">
                                    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#importmodal" id="importInfo">Import</button>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="File">Slug:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" value="<?php echo $file['slug']; ?>" name="slug" id="slug">
                            </div>
                        </div>
                        <div class="from-group col-md-4">
                            <label for="File">Thumb:</label>
                            <select name="thumbfrom" class="form-control" id="thumbfrom">
                                <option value="LOCAL">LOCAL</option>
                                <option value="EXTERNAL_LINK">URL</option>
                            </select>
                        </div>
                        <?php if ($file['thumb'] != "") :
                            $SIZE = explode(',', FILE_THUMB_SIZES);
                            if (count($SIZE) > 1) {
                                $SIZE = $SIZE[1];
                            } else {
                                $SIZE = $SIZE[0];
                            }
                        ?>
                            <div id="thumbnail">
                                <div class="col-12">
                                    <div>Thumbnail:</div>
                                    <div>
                                        <img src="<?php echo '../../' . $category['folder'] . $SIZE . '/' . $file['thumb']; ?>" class="img-thumbnail" id="thumb" alt="thumbnal" width="200" height="200">
                                        <button type="button" class="removethumb btn btn-danger">Delete</button>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div id="thumb_file_display" class="form-group col-md-6">
                            <label for="thumb">Thumb File:</label>
                            <div class="custom-file">
                                <label for="thumb" class="custom-file-label">Choose File</label>
                                <input type="file" name="thumb" class="custom-file-input" id="thumbfile" />
                            </div>
                        </div>
                        <div id="thumb_url_display" style="display: none;" class="form-group col-md-6">
                            <label for="File">Thumb URL:</label>
                            <div class="input-group">
                                <input type="text" class="form-control" name="thumb_url" id="thumb_url" placeholder="Enter Valid URL">
                            </div>
                        </div>
                        <div class="col-md-3 text-center">
                            Watermark Postion:
                            <div>
                                <input type="radio" name="w_pos" value="top-left" checked>
                                <input type="radio" name="w_pos" value="top">
                                <input type="radio" name="w_pos" value="top-right"><br>
                                <input type="radio" name="w_pos" value="left">
                                <input type="radio" name="w_pos" value="center">
                                <input type="radio" name="w_pos" value="right"><br>
                                <input type="radio" name="w_pos" value="bottom-left">
                                <input type="radio" name="w_pos" value="bottom">
                                <input type="radio" name="w_pos" value="bottom-right"><br>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="des">Directors:</label>
                            <input type="text" class="form-control tags" value="<?php echo $file['director']; ?>" name="director" id="filedirector" placeholder="">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="des">Stars:</label>
                            <input type="text" class="form-control tags" value="<?php echo $file['star']; ?>" name="star" id="filestar" placeholder="">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="des">Genre:</label>
                            <select name="genre[]" class="form-control" id="filegenre" multiple="multiple">
                                <?php
                                if ($file['genre']) {
                                    $genres = explode(',', $file['genre']);
                                    foreach ($genres as $gr) {
                                        echo '<option value="' . $gr . '" selected>' . $gr . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group col-md-2">
                            <label for="des">Duration:<small>In Minute</small></label>
                            <input type="text" class="form-control" value="<?php echo $file['duration']; ?>" name="duration" id="duration">
                        </div>
                        <div class="form-group col-md-2">
                            <label for="des">Rating: <small>Value/10</small></label>
                            <input type="text" class="form-control" name="rating" id="rating" value="<?php echo $file['rating']; ?>">
                        </div>
                        <div class="form-group col-md-2">
                            <label for="des">Total Rating:</label>
                            <input type="text" class="form-control" name="total_rate" id="total_rate" value="<?php echo $file['total_rate']; ?>">
                        </div>

                        <div class="form-group col-md-4">
                            <label for="des">Release Date:</label>
                            <input type="date" value="<?php echo date('Y-m-d', strtotime($file['release_date'])); ?>" class="form-control" name="release_date" id="release_date">
                        </div>
                        <div class="form-group col-md-12">
                            <label for="des">Description:</label>
                            <textarea name="description" id="description" class="form-control htmleditor"><?php echo $file['des']; ?></textarea>
                        </div>

                        <div id="external_display" class="col-md-12 mt-2 mb-2 shadow-lg p-2 rounded">
                            <h6 class="text-primary border-bottom p-2">Download Links:</h6>
                            <div class="form-row">
                                <div class="form-group col-md-8">
                                    <label for="">URL:</label>
                                    <div class="input-group">
                                        <div class="input-group-pepend">
                                            <select id="linkType" class="form-control">
                                                <option value="LINK">Download Link</option>
                                                <option value="EMBED">Embed Link</option>
                                            </select>
                                        </div>
                                        <input type="text" id="e_url" class="form-control" placeholder="Example: https://example.com/download/abcdef">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="">Link Name:</label>
                                    <div class="input-group">
                                        <input type="text" id="e_name" class="form-control">
                                        <div class="input-group-append">
                                            <button type="button" class="btn btn-info" id="addLink">Add Link</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <table class="table table-bordered mt-2">
                                <thead>
                                    <tr>
                                        <th width="50">Type</th>
                                        <th>URL</th>
                                        <th>Name</th>
                                        <th width="50px;"></th>
                                    </tr>
                                </thead>
                                <tbody class="linksbody">
                                    <?php $links = getDownLinks($file['id']);
                                    if ($links) {
                                        foreach ($links as $link) {
                                            echo '<tr>';
                                            echo '<td>';
                                            echo ($link['is_link'] == true) ? 'link' : 'embed';
                                            echo '</td>';
                                            echo '<td>';
                                            echo $link['link'];
                                            echo '</td>';
                                            echo '<td>';
                                            echo $link['name'];
                                            echo '</td>';
                                            echo '<td><button type="button" id="' . $link['id'] . '" class="btn btn-danger linkdelete">Delete</button>';
                                            echo '</tr>';
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-8 form-group">
                            <label for="name">Title</label>
                            <input type="text" name="meta_title" id="meta_title" value="<?php echo $file['meta_title']; ?>" class="form-control">
                        </div>

                        <div class="col-md-12 form-group">
                            <label for="meta_keyw">Keywords</label>
                            <input type="text" name="meta_keyw" value="<?php echo $file['meta_keyw']; ?>" id="meta_keyw" class="form-control">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="meta_des">Description</label>
                            <input type="text" name="meta_des" value="<?php echo $file['meta_des']; ?>" id="meta_des" class="form-control">
                        </div>
                        <div class="col-6 col-md-2">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Order:</span>
                                </div>
                                <input type="text" name="pos" id="pos" value="<?php echo $file['pos']; ?>" placeholder="" class="form-control">
                            </div>
                        </div>
                        <div class="form-group col-xs-3">
                            <label for="appname">New Badge:</label>
                            <input type="checkbox" class="form-control" data-toggle="switch" name="new_tag" value="1" <?php echo ($file['newtag'] == true) ? ' checked' : '' ?> />
                        </div>
                        <div class="form-group col-xs-3">
                            <label for="appname">Trend:</label>
                            <input type="checkbox" class="form-control" data-toggle="switch" name="trend" value="1" <?php echo ($file['trend'] == true) ? ' checked' : '' ?> />
                        </div>
                        <div class="form-group col-xs-3">
                            <label for="status">Status:</label>
                            <input type="checkbox" class="form-control" data-toggle="switch" name="status" value="1" <?php echo ($file['status'] == true) ? ' checked' : '' ?> />
                        </div>
                    </div>
                    <div class="row justify-content-end">
                        <input type="hidden" name="imdbid" id="imdbid" value="<?php echo $file['imdbid']; ?>">
                        <button type="submit" id="submit" class="btn btn-primary" name="submit" value="submit">Submit</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
    <div class="modal fade" id="importmodal" tabindex="-1" role="dialog" aria-labelledby="importmodal" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Import Movie from IMDB</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="input-group">
                        <input type="text" class="form-control" id="moviequary" placeholder="Enter Movie Name or IMDB URL">
                        <div class="input-group-append"><button type="button" class="btn btn-primary" id="movieSearch"><i class="fa fa-search" aria-hidden="true"></i></button></div>
                    </div>
                </div>
                <h5 class="text-primary border-bottom p-2">Results:</h5>
                <div id="display_movie_search" class="p-2">
                    <ul class="list-group" id="movie_results">
                    </ul>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php } else {
    echo '<div class="alert">File / Category ID Missing << <a href="../index.php"> Home</a></div> 
';
}
?>
<?php
require_once __DIR__ . '/../footer.php';
?>
<?php
error_reporting(0);
if (!session_id())
        session_start();
$RootPath = realpath(__DIR__ . '/../../');
if (!file_exists($RootPath . '/lock.txt')) {
        header('Location: ../install');
}
$AppVersion = @file_get_contents($RootPath . '/config/version');
require_once $RootPath . '/vendor/autoload.php';
require_once $RootPath . '/config/config.php';
require_once $RootPath . '/config/database.php';
require_once $RootPath . '/config/language.php';
require_once __DIR__ . '/getid3/getid3.php';
$AdminURL = APP_URL . '/' . ADMIN_DIR;
$AuthCheck = (isset($Notlogged) == true) ? false : true;
if ($AuthCheck == true) {
        if (!isset($_SESSION['id']) && !isset($_SESSION['username'])) {
                header('Location: ' . APP_URL . '/' . ADMIN_DIR . '/user/login.php');
                exit;
        }
}
$db = new MysqliDb(array(
        'host' => $dbhost,
        'username' => $dbuser,
        'password' => $dbpass,
        'db' => $dbname,
        'port' => $dbport,
        'prefix' => $dbprefix,
        'charset' => $dbcharset
));
require_once __DIR__ . '/function.php';

$allowExt = array('jpg', 'png', 'gif', 'jpeg', 'webp', 'mp4', 'mkv', 'wmv', 'mov');
$notification = array();
$alertdate = date('d M,Y');
if (!extension_loaded('gd') && !function_exists('gd_info')) {
        array_push($notification, ['date' => $alertdate, 'text' => 'Required GD Library for Thumbnail Generator']);
}

if (!version_compare(PHP_VERSION, '7.4.0', '>=')) {
        array_push($notification, ['date' => $alertdate, 'text' => 'Update PHP version 7.4 or more']);
}
if (!extension_loaded('fileinfo')) {
        array_push($notification, ['date' => $alertdate, 'text' => 'fileinfo extension required']);
}

if (!function_exists('curl_init')) {
        array_push($notification, ['date' => $alertdate, 'text' => 'Required cURL PHP extension']);
}
if (!ini_get('allow_url_fopen')) {
        array_push($notification, ['date' => $alertdate, 'text' => 'Enable allow_url_fopen in your php.ini']);
}
unset($alertdate);

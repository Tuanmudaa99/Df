<?php
require_once '../header.php';
   $AdsDirectory = $RootPath.'/templates/ads';
   $selectFile = '';
   if(!is_dir($AdsDirectory)){
	   mkdir($AdsDirectory);
	   mkdir($AdsDirectory.'/DEFAULT');
	   WriteFile($AdsDirectory.'/.htaccess','Deny from all');
   }

	$dir = Input('dir') ? Input('dir')."/" : "";

	$fileName = array();
	// Note that !== did not exist until 4.0.0-RC2

	if ($handle = opendir($AdsDirectory.'/'.$dir)) {
	   //echo "Directory handle: $handle\n";
	   $allowExt = array('.txt','.php','.css');
		while (false !== ($file = readdir($handle))) {
			if(in_array(substr($file, -4), $allowExt)) {
				$fileName[$file] = $file;
			}
		}
		sort($fileName);
		closedir($handle);
	}

	if(Input('save')){
		$selectFile = Input('Filename');
		$filenm = $AdsDirectory.'/'.$dir.$selectFile;
	
		if(Input('chmod')!='')
			chmod($filenm, Input('chmod'));
		if(file_exists($filenm))
			unlink($filenm);
		$handle = fopen($filenm, 'w');
		fwrite($handle, filter_input(INPUT_POST,'ad_content'));
		fclose($handle);
	}
	
	$content='';
	if(Input('Filename') != '') {
		$selectFile = Input('Filename');
		$filenm = $AdsDirectory.'/'.$dir.$selectFile;
	
		if(file_exists($filenm)) {
			$lines = file($filenm);
			foreach ($lines as $line_num => $line) {
				$content .= $line;
			}
		}
	}
?>
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">

            <div class="d-flex justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Ads Code Editor</h6>
            </div>
        </div>
        <div class="card-body">
<form action="" method="post" name="mail_format">
<div class="form-row">
		<div class="form-group col-12">
			<?php
				echo '<label>Select NetWork: </label>&nbsp;';
				$directories = explode(',',ADS_NETWORK);
				asort($directories);
				foreach($directories as $value){
					if(!is_dir($AdsDirectory.'/'.$value)){
					folder_Copy($AdsDirectory. '/DEFAULT', $AdsDirectory . '/' . $value);
					}
                    if($value==Input('dir'))
                     echo '<span>'.$value.'</span>';
                    else
                    echo '<span><a href="?dir='.$value.'">'.$value.'</a></span>';
					echo '&nbsp;';
				}
				?>
		</div>
		<div class="form-group col-12">
			<?php
			if(count($fileName)==0){
				echo "<br/>Placement Not Found Here.. Plz Select Site";
			}
			else{
				echo '<label>Select Placement</label>';
				echo '<input name="chmod" type="hidden" value="'.Input('chmod').'">';
				echo '<select name="Filename" class="form-control" onchange="document.mail_format.submit();">';
					echo '<option disabled selected>Select Ad File</option>';
				foreach($fileName as $key => $value){
					echo '<option value="'.$value.'" '.($value==$selectFile ? 'selected':'').'>'.pathinfo($value,PATHINFO_FILENAME).'</option>';
				}
				echo '</select>';
			}
			?>
		</div>
		<?php
		if(Input('Filename') != '') {
		?>
		<div class="form-group col-12">
        	<label>Advertisement File Content</label>
			<?php echo '<textarea name="ad_content" class="form-control" rows="10">'.$content.'</textarea>'; ?>
		</div>
	<div class="p-2">
			<input type="submit" class="btn btn-primary m-2" value="Save" name="save"/> 
			<input type="reset" class="btn btn-info m-2" value="Cancel" id="cancel" name="cancel"/>
</div>
		<?php
		}
		?>
</div>
</form>
</div>
</div>
</div>
<?php
require_once '../footer.php';
?>
<?php

/**
 * @author Pratik Dev <webmaster.pratik@gmail.com>
 */
header('Content-Type: application/json; charset=utf-8');
require_once '../config/init.php';
$currentAction = Input('submit');
if ($currentAction == 'list') {
    $searchValue = dtsValue();
    if ($searchValue) {
        $db->where('ads_url', '%' . $searchValue . '%', 'LIKE');
    }
    if (InputArray('order')) {
        $column = dtOrderby();
        if ($column == 1)
            $db->orderBy('ads_url', dtOrderby(false));
        else
            $db->orderBy('id', dtOrderby(false));
    } else {
        $db->orderBy('id');
    }
    if (Input('length') != -1) {
        $categories = $db->withTotalCount()->get('adschanger', array(dtlimit(), dtlimit(false)));
    } else {
        $categories = $db->withTotalCount()->get('adschanger');
    }
    $numRows = $db->totalCount;
    $data = array();
    foreach ($categories as $cat) {
        $row = array();
        $row[] = $cat['id'];
        $row[] = $cat['ads_url'];
        $row[] = $cat['ads_network'];
        $row[] = '<button type="button" name="delete" id="' . $cat["id"] . '" class="delete btn btn-danger btn-sm">Delete</button>';
        $data[] = $row;
    }
    $output = array(
        "draw"                =>    intval(Input('draw')),
        "recordsTotal"      =>  $numRows,
        "recordsFiltered"     =>     $numRows,
        "data"                =>   $data
    );
    echo json_encode($output);
} else if ($currentAction == 'delete') {
    if ($db->where('id', Input('id'))->delete('adschanger')) {
        $data = [
            'status' => 1,
            'message' => 'Deleted Sucessfuly'
        ];
    } else {
        $data = [
            'status' => 0,
            'message' => 'Delete Unsucessfuly'
        ];
    }

    echo json_encode($data);
} else if ($currentAction == 'create') {

    $old_url = Input('ads_url');
    $new_url = Input('ads_network');

    if (!filter_var($old_url, FILTER_VALIDATE_URL)) {
        $data = [
            'status' => 0,
            'message' => 'Please Enter Validate URL'
        ];
        echo json_encode($data);
        exit;
    }


    $parsed_url = parse_url($old_url);
    $scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
    $host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
    $path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';

    $old_url = $host . $path;
    $old_url = trim($old_url, '/');

    if (empty($old_url)) {
        $data = [
            'status' => 0,
            'message' => 'Please Enter Validate URL'
        ];
        echo json_encode($data);
        exit;
    }

    $found = $db->where('ads_url', $old_url)->getValue('adschanger', 'count(id)');
    if ($found > 0) {
        $db->where('ads_url', $old_url)->delete('adschanger');
    }

    $newdata = [
        'ads_url' => $old_url,
        'ads_network' => $new_url
    ];

    if ($db->insert('adschanger', $newdata)) {
        $data = [
            'status' => 1,
            'message' => 'Created Sucessfuly'
        ];
    } else {
        $data = [
            'status' => 0,
            'message' => 'Created Unsucessfuly'
        ];
    }
    echo json_encode($data);
    exit;
} elseif ($currentAction == 'multipledelete') {
    $ids = InputArray('ids');
    if (!$ids) {
        echo json_encode(['status' => 0, 'message' => 'Sorry No item Selected']);
        exit;
    }
    $cnt = 0;
    foreach ($ids as $id) {
        if (!$id) {
            continue;
        }
        if ($db->where('id', $id)->delete('adschanger')) {
            $cnt++;
        }
    }

    echo json_encode(['status' => 1, 'message' => 'Deleted Total: ' . $cnt . ' Items']);
}

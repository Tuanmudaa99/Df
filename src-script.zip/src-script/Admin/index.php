<?php

/**
 * @author Pratik Dev <webmaster.pratik@gmail.com>
 */
require_once 'header.php';
$_files = $db->getValue(TABLE_FILES, 'count(id)');
$_cats =  $db->getValue(TABLE_CAT, 'count(id)');
$_download = $db->getValue(TABLE_FILES, 'sum(view)');
$_uploads = $db->where('created_at', date('Y-m-d') . '%', 'LIKE')->getValue(TABLE_FILES, 'count(id)');
$max_upload_mb = formatSize(file_upload_max_size());
// $serverload = sys_getloadavg();
function file_upload_max_size()
{
    static $max_size = -1;

    if ($max_size < 0) {
        // Start with post_max_size.
        $post_max_size = parse_size(ini_get('post_max_size'));
        if ($post_max_size > 0) {
            $max_size = $post_max_size;
        }

        // If upload_max_size is less, then reduce. Except if upload_max_size is
        // zero, which indicates no limit.
        $upload_max = parse_size(ini_get('upload_max_filesize'));
        if ($upload_max > 0 && $upload_max < $max_size) {
            $max_size = $upload_max;
        }
    }
    return $max_size;
}


function parse_size($size)
{
    $unit = preg_replace('/[^bkmgtpezy]/i', '', $size); // Remove the non-unit characters from the size.
    $size = preg_replace('/[^0-9\.]/', '', $size); // Remove the non-numeric characters from the size.
    if ($unit) {
        // Find the position of the unit in the ordered string which is the power of magnitude to multiply a kilobyte by.
        return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
    } else {
        return round($size);
    }
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Content Row -->
    <div class="row">
        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                Movies</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_files; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Categories</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_cats; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-sitemap fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                Uploads</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_uploads; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-upload fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Pending Requests Card Example -->
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                Total Views</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $_download; ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-eye fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">System Overview</h6>
                    <button class="btn btn-primary" type="button" id="sitemapgen">Sitemap Generate</button>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <table class="table table-bordered tx-gray-700 bd ">
                        <tbody>
                            <tr>
                                <td>Operating System</td>
                                <td class="text-primary"><?php echo PHP_OS; ?></td>
                            </tr>
                            <tr>
                                <td>PHP Version</td>
                                <td><?php echo phpversion();?></td>
                            </tr>
                            <tr>
                                <td>Server IP</td>
                                <td class="text-success"><?php echo $_SERVER['SERVER_ADDR'] ?></td>
                            </tr>
                            <tr>
                                <td>Your PC IP</td>
                                <td class="text-primary"><?php echo $_SERVER['REMOTE_ADDR']; ?></td>
                            </tr>
                            <tr>
                                <td>Server Date & Time </td>
                                <td class="text-warning">
                                    <?php
                                    $time = date('d,M y H:i:s', time());
                                    echo '' . $time . '';
                                    ?>
                                </td>
                            </tr>
                            <tr>
                                <td>Upload Limit:</td>
                                <td class="text-danger"><?php echo $max_upload_mb; ?></td>
                            </tr>
                            <tr>

                                <td>Server Disk Space</td>
                                <td class="text-danger"><?php
                                                        $base = 1024;
                                                        $bytes = disk_total_space(".");
                                                        $si_prefix = array('B', 'KB', 'MB', 'GB', 'TB', 'EB', 'ZB', 'YB');
                                                        $class = min((int)log($bytes, $base), count($si_prefix) - 1);
                                                        //echo $bytes . '<br />';
                                                        echo sprintf('%1.2f', $bytes / pow($base, $class)) . ' ' . $si_prefix[$class] . '';
                                                        ?></td>

                            </tr>
                            <tr>
                                <td>Server Disk Space Free</td>
                                <td class="text-danger"><?php
                                                        $bytes = disk_free_space(".");
                                                        $class = min((int)log($bytes, $base), count($si_prefix) - 1);
                                                        echo sprintf('%1.2f', $bytes / pow($base, $class)) . ' ' . $si_prefix[$class] . '';
                                                        ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <!-- Content Row -->
    <?php /* 
    
        <!-- Area Chart -->
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Downloads Overview</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="downloadedchart"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">App Updated</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="appupdate"></canvas>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-warning">Updated Failed</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="appupdatefailed"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div> --> */ ?>
</div>
<!-- /.container-fluid -->
<?php
$HomeIndex = true;
require_once 'footer.php';
